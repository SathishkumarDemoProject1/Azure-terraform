Project side changes
 1. Build your project and create a docker image for you project.
 2. Push your image to docker repository.
 
In terraform
 1. Create resource group
 2. Create private network with CIDR
 3. Create subnet
 4. Create Public IP
 5. Create load Balancer    // Balancing the load accross multiple VMs
 6. Create Backend address Pool  // Group all the Vm's under single pool
 7. Create health probe   // Health check end point for load balancer
 8. Create load balancer rule 
 9. Create VM scale set (Linux) // Configure Vm image and properties.
 8. Create scaling policy  // increase +1vm when vm pool CPU percentage is 75%, decrease -1vm when vm pool CPU percentage is 25%
 10. Create custom_script extension // Deploy our application into the vm's