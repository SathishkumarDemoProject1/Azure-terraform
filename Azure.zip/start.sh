mvn clean install

docker login http://registry.hub.docker.com

docker build -t spring-petclinic .

docker tag spring-petclinic:latest sathishkumar281995/spring-petclinic:latest

docker push sathishkumar281995/spring-petclinic:latest
